﻿Public Class Form2



    Private Sub Form2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ToolTip1.AutoPopDelay = 32000
        ToolTip1.InitialDelay = 1000
        ToolTip1.ReshowDelay = 500
        ToolTip1.SetToolTip(GroupBox5, "These radio buttons control the DTMF tone and button press duration for programming" & vbCrLf & _
        Chr(149) & "The normal selection uses an 80 millisecond duration" & vbCrLf & _
        Chr(149) & "The slow selection uses a 250 millisecond duration" & vbCrLf & _
        Chr(149) & "The debug selection uses a 1 second duration (this is slow enough that one can follow the actual commands being sent to the radio" & vbCrLf & _
        "These selections are useful for different radio models/firmware.  If the normal (default) duration does not work properly, try the slow setting")

        Mod1None.Checked() = True
        Mod2None.Checked() = True
        Mod3None.Checked() = True
    End Sub

    Private Sub ChannelLists_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ChannelLists.Click
        If Mod1None.Checked = True And Mod2None.Checked = True And Mod3None.Checked = True Then
            MsgBox("At least one module must be selected to continue.", MsgBoxStyle.Critical, "Module selection check")
            Return
        End If

        Me.Visible = False
        Dim y As Integer

        y = 2
        Form1.TabControl.SelectedIndex = y
        If Mod3UT30.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod3UT30.Text
        ElseIf Mod3UT50.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod3UT50.Text
        ElseIf Mod3UT144.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod1UT144.Text + "e"
        ElseIf Mod3UT144.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod3UT144.Text
        ElseIf Mod3UT220.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod3UT220.Text
        ElseIf Mod3UT440.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod3UT440.Text + "e"
        ElseIf Mod3UT440.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod3UT440.Text
        ElseIf Mod3UT1200.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod3UT1200.Text + "e"
        ElseIf Mod3UT1200.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod3UT1200.Text
        End If
        If Mod3None.Checked = True Then
            Form1.TabControl.SelectedTab.Text = "Mod3 Not Installed"
            Form1.Panel20.Enabled = False
            Form1.Panel22.Enabled = False
            Form1.Panel23.Enabled = False
        Else
            Form1.Panel20.Enabled = True
            Form1.Panel22.Enabled = True
            Form1.Panel23.Enabled = True
        End If

        y = 1
        Form1.TabControl.SelectedIndex = y
        If Mod2UT30.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod2UT30.Text
        ElseIf Mod2UT50.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod2UT50.Text
        ElseIf Mod2UT144.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod1UT144.Text + "e"
        ElseIf Mod2UT144.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod2UT144.Text
        ElseIf Mod2UT220.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod2UT220.Text
        ElseIf Mod2UT440.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod2UT440.Text + "e"
        ElseIf Mod2UT440.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod2UT440.Text
        ElseIf Mod2UT1200.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod2UT1200.Text + "e"
        ElseIf Mod2UT1200.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod2UT1200.Text
        End If
        If Mod2None.Checked = True Then
            Form1.TabControl.SelectedTab.Text = "Mod2 Not Installed"
            Form1.Panel11.Enabled = False
            Form1.Panel12.Enabled = False
            Form1.Panel15.Enabled = False
        Else
            Form1.Panel11.Enabled = True
            Form1.Panel12.Enabled = True
            Form1.Panel15.Enabled = True
        End If

        y = 0
        Form1.TabControl.SelectedIndex = y
        If Mod1UT30.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod1UT30.Text
        ElseIf Mod1UT50.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod1UT50.Text
        ElseIf Mod1UT144.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod1UT144.Text + "e"
        ElseIf Mod1UT144.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod1UT144.Text
        ElseIf Mod1UT220.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod1UT220.Text
        ElseIf Mod1UT440.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod1UT440.Text + "e"
        ElseIf Mod1UT440.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod1UT440.Text
        ElseIf Mod1UT1200.Checked And eTypeRadioCheckBox.Checked Then
            Form1.TabControl.SelectedTab.Text = Mod1UT1200.Text + "e"
        ElseIf Mod1UT1200.Checked = True Then
            Form1.TabControl.SelectedTab.Text = Mod1UT1200.Text
        End If
        If Mod1None.Checked = True Then
            Form1.TabControl.SelectedTab.Text = "Mod1 Not Installed"
            Form1.Panel1.Enabled = False
            Form1.Panel2.Enabled = False
            Form1.Panel3.Enabled = False
        Else
            Form1.Panel1.Enabled = True
            Form1.Panel2.Enabled = True
            Form1.Panel3.Enabled = True
        End If

        'Dim test As String
        'Dim MhzComboBoxObj As Object
        Dim startVal As Integer
        Dim stopVal As Integer
        Dim addDoubleMinus As Boolean = False
        Dim repeaterComboBoxObj As ComboBox
        Dim tabString As String
        Dim mhzComboBoxObj As ComboBox
        Dim listViewObj As ListView
        Dim ctcssXmitRecObj As RadioButton
        Dim channelListViewObj As ListView

        For x As Integer = 0 To 2

            If x = 0 Then
                channelListViewObj = Form1.Tab1ChannelListView
                ctcssXmitRecObj = Form1.Tab1CtcssXmitRec
                listViewObj = Form1.Tab1ChannelListView
                mhzComboBoxObj = Form1.Tab1MHzComboBox
                repeaterComboBoxObj = Form1.Tab1RepeaterComboBox
                Form1.TabControl.SelectedIndex = x
                tabString = Form1.TabControl.SelectedTab.Text
            ElseIf x = 1 Then
                channelListViewObj = Form1.Tab2ChannelListView
                ctcssXmitRecObj = Form1.Tab2CtcssXmitRec
                listViewObj = Form1.Tab2ChannelListView
                mhzComboBoxObj = Form1.Tab2MHzComboBox
                repeaterComboBoxObj = Form1.Tab2RepeaterComboBox
                Form1.TabControl.SelectedIndex = x
                tabString = Form1.TabControl.SelectedTab.Text
            Else
                channelListViewObj = Form1.Tab3ChannelListView
                ctcssXmitRecObj = Form1.Tab3CtcssXmitRec
                listViewObj = Form1.Tab3ChannelListView
                mhzComboBoxObj = Form1.Tab3MHzComboBox
                repeaterComboBoxObj = Form1.Tab3RepeaterComboBox
                Form1.TabControl.SelectedIndex = x
                tabString = Form1.TabControl.SelectedTab.Text
            End If

            channelListViewObj.Items.Clear()

            repeaterComboBoxObj.Items.Clear()
            repeaterComboBoxObj.Items.Add("SIMPLEX")
            repeaterComboBoxObj.Items.Add("PLUS")
            repeaterComboBoxObj.Items.Add("MINUS")

            If ((x = 0 And ((Mod1UT440.Checked And eTypeRadioCheckBox.Checked) Or (Mod1UT1200.Checked And Not (eTypeRadioCheckBox.Checked)))) Or (x = 1 And ((Mod2UT440.Checked And eTypeRadioCheckBox.Checked) Or (Mod2UT1200.Checked And Not (eTypeRadioCheckBox.Checked)))) Or (x = 2 And ((Mod3UT440.Checked And eTypeRadioCheckBox.Checked) Or (Mod3UT1200.Checked And Not (eTypeRadioCheckBox.Checked))))) Then
                repeaterComboBoxObj.Items.Add("DBL MINUS")
            End If

            Form1.TabControl.SelectedIndex = x
            If Form1.TabControl.SelectedTab.Text = Mod1UT30.Text Or Form1.TabControl.SelectedTab.Text = Mod2UT30.Text Or Form1.TabControl.SelectedTab.Text = Mod3UT30.Text Then
                startVal = 28
                stopVal = 29
            ElseIf Form1.TabControl.SelectedTab.Text = Mod1UT50.Text Or Form1.TabControl.SelectedTab.Text = Mod2UT50.Text Or Form1.TabControl.SelectedTab.Text = Mod3UT50.Text Then
                startVal = 50
                stopVal = 53
            ElseIf Form1.TabControl.SelectedTab.Text = Mod1UT144.Text Or Form1.TabControl.SelectedTab.Text = (Mod1UT144.Text + "e") Or Form1.TabControl.SelectedTab.Text = Mod2UT144.Text Or Form1.TabControl.SelectedTab.Text = (Mod2UT144.Text + "e") Or Form1.TabControl.SelectedTab.Text = Mod3UT144.Text Or Form1.TabControl.SelectedTab.Text = (Mod3UT144.Text + "e") Then
                startVal = 118
                stopVal = 174
            ElseIf Form1.TabControl.SelectedTab.Text = Mod1UT220.Text Or Form1.TabControl.SelectedTab.Text = Mod2UT220.Text Or Form1.TabControl.SelectedTab.Text = Mod3UT220.Text Then
                startVal = 220
                stopVal = 224
            ElseIf Form1.TabControl.SelectedTab.Text = Mod1UT440.Text Or Form1.TabControl.SelectedTab.Text = (Mod1UT440.Text + "e") Or Form1.TabControl.SelectedTab.Text = Mod2UT440.Text Or Form1.TabControl.SelectedTab.Text = (Mod2UT440.Text + "e") Or Form1.TabControl.SelectedTab.Text = Mod3UT440.Text Or Form1.TabControl.SelectedTab.Text = (Mod3UT440.Text + "e") Then
                startVal = 410
                stopVal = 470
            ElseIf Form1.TabControl.SelectedTab.Text = Mod1UT1200.Text Or Form1.TabControl.SelectedTab.Text = (Mod1UT1200.Text + "e") Or Form1.TabControl.SelectedTab.Text = Mod2UT1200.Text Or Form1.TabControl.SelectedTab.Text = (Mod2UT1200.Text + "e") Or Form1.TabControl.SelectedTab.Text = Mod3UT1200.Text Or Form1.TabControl.SelectedTab.Text = (Mod3UT1200.Text + "e") Then
                startVal = 1240
                stopVal = 1299
                If wideBandCheckBox.Checked Then
                    startVal = 1100
                    stopVal = 1399
                End If
            End If

            mhzComboBoxObj.Items.Clear()
            mhzComboBoxObj.Items.Add("BLANK")
            While startVal <= stopVal
                mhzComboBoxObj.Items.Add(Convert.ToString(startVal))
                startVal += 1
            End While

            listViewObj.Text = "BLANK"
            If Tsu7CheckBox.Checked Then
                ctcssXmitRecObj.Visible = True
                ctcssXmitRecObj.Update()
            Else
                ctcssXmitRecObj.Visible = False
                ctcssXmitRecObj.Update()
            End If
        Next

        Form1.initializeForm()
        Form1.Visible = True

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing

        Static test As Boolean = False
        If (test = False) Then
            test = True
            Form1.Close()
            Me.Close()
        End If

    End Sub

    Private Sub eTypeRadioCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles eTypeRadioCheckBox.CheckedChanged
        Dim ut220Checked As Boolean = False
        If eTypeRadioCheckBox.Checked Then
            If Mod1UT220.Checked Then
                Mod1UT220.Checked = False
                Mod1None.Checked = True
                ut220Checked = True
            End If
            If Mod2UT220.Checked Then
                Mod2UT220.Checked = False
                Mod2None.Checked = True
                ut220Checked = True
            End If
            If Mod3UT220.Checked Then
                Mod3UT220.Checked = False
                Mod3None.Checked = True
                ut220Checked = True
            End If

            Mod1UT220.Enabled = False
            Mod2UT220.Enabled = False
            Mod3UT220.Enabled = False

            If ut220Checked = True Then
                Dim msgResult As MsgBoxResult = MsgBox("UT220 module is not a valid selection with an 'E' type radio.")
            End If
        Else
            Mod1UT220.Enabled = True
            Mod2UT220.Enabled = True
            Mod3UT220.Enabled = True
        End If
    End Sub
End Class