﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel
        Me.TableLayoutPanel2 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Mod2None = New System.Windows.Forms.RadioButton
        Me.Mod2UT1200 = New System.Windows.Forms.RadioButton
        Me.Mod2UT440 = New System.Windows.Forms.RadioButton
        Me.Mod2UT30 = New System.Windows.Forms.RadioButton
        Me.Mod2UT220 = New System.Windows.Forms.RadioButton
        Me.Mod2UT50 = New System.Windows.Forms.RadioButton
        Me.Mod2UT144 = New System.Windows.Forms.RadioButton
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Mod1None = New System.Windows.Forms.RadioButton
        Me.Mod1UT1200 = New System.Windows.Forms.RadioButton
        Me.Mod1UT440 = New System.Windows.Forms.RadioButton
        Me.Mod1UT30 = New System.Windows.Forms.RadioButton
        Me.Mod1UT220 = New System.Windows.Forms.RadioButton
        Me.Mod1UT50 = New System.Windows.Forms.RadioButton
        Me.Mod1UT144 = New System.Windows.Forms.RadioButton
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Mod3None = New System.Windows.Forms.RadioButton
        Me.Mod3UT1200 = New System.Windows.Forms.RadioButton
        Me.Mod3UT440 = New System.Windows.Forms.RadioButton
        Me.Mod3UT30 = New System.Windows.Forms.RadioButton
        Me.Mod3UT220 = New System.Windows.Forms.RadioButton
        Me.Mod3UT50 = New System.Windows.Forms.RadioButton
        Me.Mod3UT144 = New System.Windows.Forms.RadioButton
        Me.TableLayoutPanel3 = New System.Windows.Forms.TableLayoutPanel
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.wideBandCheckBox = New System.Windows.Forms.CheckBox
        Me.eTypeRadioCheckBox = New System.Windows.Forms.CheckBox
        Me.Tsu7CheckBox = New System.Windows.Forms.CheckBox
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.ChannelLists = New System.Windows.Forms.Button
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.normalRadioTimingButton = New System.Windows.Forms.RadioButton
        Me.slowRadioTimingButton = New System.Windows.Forms.RadioButton
        Me.debugRadioTimingButton = New System.Windows.Forms.RadioButton
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.TableLayoutPanel2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TableLayoutPanel3.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.ColumnCount = 1
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel2, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.TableLayoutPanel3, 0, 1)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 2
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 69.46565!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30.53435!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(382, 345)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'TableLayoutPanel2
        '
        Me.TableLayoutPanel2.ColumnCount = 3
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.17544!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.82456!))
        Me.TableLayoutPanel2.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 136.0!))
        Me.TableLayoutPanel2.Controls.Add(Me.Panel2, 1, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel3, 0, 0)
        Me.TableLayoutPanel2.Controls.Add(Me.Panel1, 2, 0)
        Me.TableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel2.Location = New System.Drawing.Point(3, 3)
        Me.TableLayoutPanel2.Name = "TableLayoutPanel2"
        Me.TableLayoutPanel2.RowCount = 1
        Me.TableLayoutPanel2.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel2.Size = New System.Drawing.Size(376, 233)
        Me.TableLayoutPanel2.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.GroupBox1)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(123, 3)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(113, 227)
        Me.Panel2.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Mod2None)
        Me.GroupBox1.Controls.Add(Me.Mod2UT1200)
        Me.GroupBox1.Controls.Add(Me.Mod2UT440)
        Me.GroupBox1.Controls.Add(Me.Mod2UT30)
        Me.GroupBox1.Controls.Add(Me.Mod2UT220)
        Me.GroupBox1.Controls.Add(Me.Mod2UT50)
        Me.GroupBox1.Controls.Add(Me.Mod2UT144)
        Me.GroupBox1.Location = New System.Drawing.Point(16, 21)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(97, 187)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Module 2"
        '
        'Mod2None
        '
        Me.Mod2None.AutoSize = True
        Me.Mod2None.Location = New System.Drawing.Point(27, 19)
        Me.Mod2None.Name = "Mod2None"
        Me.Mod2None.Size = New System.Drawing.Size(51, 17)
        Me.Mod2None.TabIndex = 6
        Me.Mod2None.TabStop = True
        Me.Mod2None.Text = "None"
        Me.Mod2None.UseVisualStyleBackColor = True
        '
        'Mod2UT1200
        '
        Me.Mod2UT1200.AutoSize = True
        Me.Mod2UT1200.Location = New System.Drawing.Point(27, 157)
        Me.Mod2UT1200.Name = "Mod2UT1200"
        Me.Mod2UT1200.Size = New System.Drawing.Size(67, 17)
        Me.Mod2UT1200.TabIndex = 5
        Me.Mod2UT1200.TabStop = True
        Me.Mod2UT1200.Text = "UT 1200"
        Me.Mod2UT1200.UseVisualStyleBackColor = True
        '
        'Mod2UT440
        '
        Me.Mod2UT440.AutoSize = True
        Me.Mod2UT440.Location = New System.Drawing.Point(27, 134)
        Me.Mod2UT440.Name = "Mod2UT440"
        Me.Mod2UT440.Size = New System.Drawing.Size(61, 17)
        Me.Mod2UT440.TabIndex = 4
        Me.Mod2UT440.TabStop = True
        Me.Mod2UT440.Text = "UT 440"
        Me.Mod2UT440.UseVisualStyleBackColor = True
        '
        'Mod2UT30
        '
        Me.Mod2UT30.AutoSize = True
        Me.Mod2UT30.Location = New System.Drawing.Point(27, 42)
        Me.Mod2UT30.Name = "Mod2UT30"
        Me.Mod2UT30.Size = New System.Drawing.Size(55, 17)
        Me.Mod2UT30.TabIndex = 0
        Me.Mod2UT30.TabStop = True
        Me.Mod2UT30.Text = "UT 30"
        Me.Mod2UT30.UseVisualStyleBackColor = True
        '
        'Mod2UT220
        '
        Me.Mod2UT220.AutoSize = True
        Me.Mod2UT220.Location = New System.Drawing.Point(27, 111)
        Me.Mod2UT220.Name = "Mod2UT220"
        Me.Mod2UT220.Size = New System.Drawing.Size(61, 17)
        Me.Mod2UT220.TabIndex = 3
        Me.Mod2UT220.TabStop = True
        Me.Mod2UT220.Text = "UT 220"
        Me.Mod2UT220.UseVisualStyleBackColor = True
        '
        'Mod2UT50
        '
        Me.Mod2UT50.AutoSize = True
        Me.Mod2UT50.Location = New System.Drawing.Point(27, 65)
        Me.Mod2UT50.Name = "Mod2UT50"
        Me.Mod2UT50.Size = New System.Drawing.Size(55, 17)
        Me.Mod2UT50.TabIndex = 1
        Me.Mod2UT50.TabStop = True
        Me.Mod2UT50.Text = "UT 50"
        Me.Mod2UT50.UseVisualStyleBackColor = True
        '
        'Mod2UT144
        '
        Me.Mod2UT144.AutoSize = True
        Me.Mod2UT144.Location = New System.Drawing.Point(27, 88)
        Me.Mod2UT144.Name = "Mod2UT144"
        Me.Mod2UT144.Size = New System.Drawing.Size(61, 17)
        Me.Mod2UT144.TabIndex = 2
        Me.Mod2UT144.TabStop = True
        Me.Mod2UT144.Text = "UT 144"
        Me.Mod2UT144.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel3.Controls.Add(Me.GroupBox2)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel3.Location = New System.Drawing.Point(3, 3)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(114, 227)
        Me.Panel3.TabIndex = 2
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Mod1None)
        Me.GroupBox2.Controls.Add(Me.Mod1UT1200)
        Me.GroupBox2.Controls.Add(Me.Mod1UT440)
        Me.GroupBox2.Controls.Add(Me.Mod1UT30)
        Me.GroupBox2.Controls.Add(Me.Mod1UT220)
        Me.GroupBox2.Controls.Add(Me.Mod1UT50)
        Me.GroupBox2.Controls.Add(Me.Mod1UT144)
        Me.GroupBox2.Location = New System.Drawing.Point(15, 21)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(97, 187)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Module 1"
        '
        'Mod1None
        '
        Me.Mod1None.AutoSize = True
        Me.Mod1None.Location = New System.Drawing.Point(27, 19)
        Me.Mod1None.Name = "Mod1None"
        Me.Mod1None.Size = New System.Drawing.Size(51, 17)
        Me.Mod1None.TabIndex = 6
        Me.Mod1None.TabStop = True
        Me.Mod1None.Text = "None"
        Me.Mod1None.UseVisualStyleBackColor = True
        '
        'Mod1UT1200
        '
        Me.Mod1UT1200.AutoSize = True
        Me.Mod1UT1200.Location = New System.Drawing.Point(27, 157)
        Me.Mod1UT1200.Name = "Mod1UT1200"
        Me.Mod1UT1200.Size = New System.Drawing.Size(67, 17)
        Me.Mod1UT1200.TabIndex = 5
        Me.Mod1UT1200.TabStop = True
        Me.Mod1UT1200.Text = "UT 1200"
        Me.Mod1UT1200.UseVisualStyleBackColor = True
        '
        'Mod1UT440
        '
        Me.Mod1UT440.AutoSize = True
        Me.Mod1UT440.Location = New System.Drawing.Point(27, 134)
        Me.Mod1UT440.Name = "Mod1UT440"
        Me.Mod1UT440.Size = New System.Drawing.Size(61, 17)
        Me.Mod1UT440.TabIndex = 4
        Me.Mod1UT440.TabStop = True
        Me.Mod1UT440.Text = "UT 440"
        Me.Mod1UT440.UseVisualStyleBackColor = True
        '
        'Mod1UT30
        '
        Me.Mod1UT30.AutoSize = True
        Me.Mod1UT30.Location = New System.Drawing.Point(27, 42)
        Me.Mod1UT30.Name = "Mod1UT30"
        Me.Mod1UT30.Size = New System.Drawing.Size(55, 17)
        Me.Mod1UT30.TabIndex = 0
        Me.Mod1UT30.TabStop = True
        Me.Mod1UT30.Text = "UT 30"
        Me.Mod1UT30.UseVisualStyleBackColor = True
        '
        'Mod1UT220
        '
        Me.Mod1UT220.AutoSize = True
        Me.Mod1UT220.Location = New System.Drawing.Point(27, 111)
        Me.Mod1UT220.Name = "Mod1UT220"
        Me.Mod1UT220.Size = New System.Drawing.Size(61, 17)
        Me.Mod1UT220.TabIndex = 3
        Me.Mod1UT220.TabStop = True
        Me.Mod1UT220.Text = "UT 220"
        Me.Mod1UT220.UseVisualStyleBackColor = True
        '
        'Mod1UT50
        '
        Me.Mod1UT50.AutoSize = True
        Me.Mod1UT50.Location = New System.Drawing.Point(27, 65)
        Me.Mod1UT50.Name = "Mod1UT50"
        Me.Mod1UT50.Size = New System.Drawing.Size(55, 17)
        Me.Mod1UT50.TabIndex = 1
        Me.Mod1UT50.TabStop = True
        Me.Mod1UT50.Text = "UT 50"
        Me.Mod1UT50.UseVisualStyleBackColor = True
        '
        'Mod1UT144
        '
        Me.Mod1UT144.AutoSize = True
        Me.Mod1UT144.Location = New System.Drawing.Point(27, 88)
        Me.Mod1UT144.Name = "Mod1UT144"
        Me.Mod1UT144.Size = New System.Drawing.Size(61, 17)
        Me.Mod1UT144.TabIndex = 2
        Me.Mod1UT144.TabStop = True
        Me.Mod1UT144.Text = "UT 144"
        Me.Mod1UT144.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(242, 3)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(131, 227)
        Me.Panel1.TabIndex = 3
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Mod3None)
        Me.GroupBox3.Controls.Add(Me.Mod3UT1200)
        Me.GroupBox3.Controls.Add(Me.Mod3UT440)
        Me.GroupBox3.Controls.Add(Me.Mod3UT30)
        Me.GroupBox3.Controls.Add(Me.Mod3UT220)
        Me.GroupBox3.Controls.Add(Me.Mod3UT50)
        Me.GroupBox3.Controls.Add(Me.Mod3UT144)
        Me.GroupBox3.Location = New System.Drawing.Point(18, 21)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(97, 187)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Module 3"
        '
        'Mod3None
        '
        Me.Mod3None.AutoSize = True
        Me.Mod3None.Location = New System.Drawing.Point(27, 19)
        Me.Mod3None.Name = "Mod3None"
        Me.Mod3None.Size = New System.Drawing.Size(51, 17)
        Me.Mod3None.TabIndex = 6
        Me.Mod3None.TabStop = True
        Me.Mod3None.Text = "None"
        Me.Mod3None.UseVisualStyleBackColor = True
        '
        'Mod3UT1200
        '
        Me.Mod3UT1200.AutoSize = True
        Me.Mod3UT1200.Location = New System.Drawing.Point(27, 157)
        Me.Mod3UT1200.Name = "Mod3UT1200"
        Me.Mod3UT1200.Size = New System.Drawing.Size(67, 17)
        Me.Mod3UT1200.TabIndex = 5
        Me.Mod3UT1200.TabStop = True
        Me.Mod3UT1200.Text = "UT 1200"
        Me.Mod3UT1200.UseVisualStyleBackColor = True
        '
        'Mod3UT440
        '
        Me.Mod3UT440.AutoSize = True
        Me.Mod3UT440.Location = New System.Drawing.Point(27, 134)
        Me.Mod3UT440.Name = "Mod3UT440"
        Me.Mod3UT440.Size = New System.Drawing.Size(61, 17)
        Me.Mod3UT440.TabIndex = 4
        Me.Mod3UT440.TabStop = True
        Me.Mod3UT440.Text = "UT 440"
        Me.Mod3UT440.UseVisualStyleBackColor = True
        '
        'Mod3UT30
        '
        Me.Mod3UT30.AutoSize = True
        Me.Mod3UT30.Location = New System.Drawing.Point(27, 42)
        Me.Mod3UT30.Name = "Mod3UT30"
        Me.Mod3UT30.Size = New System.Drawing.Size(55, 17)
        Me.Mod3UT30.TabIndex = 0
        Me.Mod3UT30.TabStop = True
        Me.Mod3UT30.Text = "UT 30"
        Me.Mod3UT30.UseVisualStyleBackColor = True
        '
        'Mod3UT220
        '
        Me.Mod3UT220.AutoSize = True
        Me.Mod3UT220.Location = New System.Drawing.Point(27, 111)
        Me.Mod3UT220.Name = "Mod3UT220"
        Me.Mod3UT220.Size = New System.Drawing.Size(61, 17)
        Me.Mod3UT220.TabIndex = 3
        Me.Mod3UT220.TabStop = True
        Me.Mod3UT220.Text = "UT 220"
        Me.Mod3UT220.UseVisualStyleBackColor = True
        '
        'Mod3UT50
        '
        Me.Mod3UT50.AutoSize = True
        Me.Mod3UT50.Location = New System.Drawing.Point(27, 65)
        Me.Mod3UT50.Name = "Mod3UT50"
        Me.Mod3UT50.Size = New System.Drawing.Size(55, 17)
        Me.Mod3UT50.TabIndex = 1
        Me.Mod3UT50.TabStop = True
        Me.Mod3UT50.Text = "UT 50"
        Me.Mod3UT50.UseVisualStyleBackColor = True
        '
        'Mod3UT144
        '
        Me.Mod3UT144.AutoSize = True
        Me.Mod3UT144.Location = New System.Drawing.Point(27, 88)
        Me.Mod3UT144.Name = "Mod3UT144"
        Me.Mod3UT144.Size = New System.Drawing.Size(61, 17)
        Me.Mod3UT144.TabIndex = 2
        Me.Mod3UT144.TabStop = True
        Me.Mod3UT144.Text = "UT 144"
        Me.Mod3UT144.UseVisualStyleBackColor = True
        '
        'TableLayoutPanel3
        '
        Me.TableLayoutPanel3.ColumnCount = 2
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 68.61702!))
        Me.TableLayoutPanel3.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 31.38298!))
        Me.TableLayoutPanel3.Controls.Add(Me.Panel5, 0, 0)
        Me.TableLayoutPanel3.Controls.Add(Me.Panel6, 1, 0)
        Me.TableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel3.Location = New System.Drawing.Point(3, 242)
        Me.TableLayoutPanel3.Name = "TableLayoutPanel3"
        Me.TableLayoutPanel3.RowCount = 1
        Me.TableLayoutPanel3.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel3.Size = New System.Drawing.Size(376, 100)
        Me.TableLayoutPanel3.TabIndex = 1
        '
        'Panel5
        '
        Me.Panel5.Controls.Add(Me.GroupBox5)
        Me.Panel5.Controls.Add(Me.GroupBox4)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel5.Location = New System.Drawing.Point(3, 3)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(251, 94)
        Me.Panel5.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.wideBandCheckBox)
        Me.GroupBox4.Controls.Add(Me.eTypeRadioCheckBox)
        Me.GroupBox4.Controls.Add(Me.Tsu7CheckBox)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 4)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(116, 100)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Radio Options"
        '
        'wideBandCheckBox
        '
        Me.wideBandCheckBox.AutoSize = True
        Me.wideBandCheckBox.Location = New System.Drawing.Point(7, 72)
        Me.wideBandCheckBox.Name = "wideBandCheckBox"
        Me.wideBandCheckBox.Size = New System.Drawing.Size(79, 17)
        Me.wideBandCheckBox.TabIndex = 3
        Me.wideBandCheckBox.Text = "Wide Band"
        Me.wideBandCheckBox.UseVisualStyleBackColor = True
        '
        'eTypeRadioCheckBox
        '
        Me.eTypeRadioCheckBox.AutoSize = True
        Me.eTypeRadioCheckBox.Location = New System.Drawing.Point(7, 51)
        Me.eTypeRadioCheckBox.Name = "eTypeRadioCheckBox"
        Me.eTypeRadioCheckBox.Size = New System.Drawing.Size(95, 17)
        Me.eTypeRadioCheckBox.TabIndex = 2
        Me.eTypeRadioCheckBox.Text = "'E' Type Radio"
        Me.eTypeRadioCheckBox.UseVisualStyleBackColor = True
        '
        'Tsu7CheckBox
        '
        Me.Tsu7CheckBox.AutoSize = True
        Me.Tsu7CheckBox.Location = New System.Drawing.Point(7, 29)
        Me.Tsu7CheckBox.Name = "Tsu7CheckBox"
        Me.Tsu7CheckBox.Size = New System.Drawing.Size(99, 17)
        Me.Tsu7CheckBox.TabIndex = 0
        Me.Tsu7CheckBox.Text = "TSU-7 Installed"
        Me.Tsu7CheckBox.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Controls.Add(Me.Panel4)
        Me.Panel6.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel6.Location = New System.Drawing.Point(260, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(113, 94)
        Me.Panel6.TabIndex = 1
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel4.Controls.Add(Me.ChannelLists)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(113, 94)
        Me.Panel4.TabIndex = 1
        '
        'ChannelLists
        '
        Me.ChannelLists.Location = New System.Drawing.Point(19, 31)
        Me.ChannelLists.Name = "ChannelLists"
        Me.ChannelLists.Size = New System.Drawing.Size(78, 39)
        Me.ChannelLists.TabIndex = 2
        Me.ChannelLists.Text = "Go To Channel Lists"
        Me.ChannelLists.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.debugRadioTimingButton)
        Me.GroupBox5.Controls.Add(Me.slowRadioTimingButton)
        Me.GroupBox5.Controls.Add(Me.normalRadioTimingButton)
        Me.GroupBox5.Location = New System.Drawing.Point(128, 4)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(92, 84)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Radio Timing"
        '
        'normalRadioTimingButton
        '
        Me.normalRadioTimingButton.AutoSize = True
        Me.normalRadioTimingButton.Checked = True
        Me.normalRadioTimingButton.Location = New System.Drawing.Point(10, 20)
        Me.normalRadioTimingButton.Name = "normalRadioTimingButton"
        Me.normalRadioTimingButton.Size = New System.Drawing.Size(58, 17)
        Me.normalRadioTimingButton.TabIndex = 0
        Me.normalRadioTimingButton.TabStop = True
        Me.normalRadioTimingButton.Text = "Normal"
        Me.normalRadioTimingButton.UseVisualStyleBackColor = True
        '
        'slowRadioTimingButton
        '
        Me.slowRadioTimingButton.AutoSize = True
        Me.slowRadioTimingButton.Location = New System.Drawing.Point(10, 43)
        Me.slowRadioTimingButton.Name = "slowRadioTimingButton"
        Me.slowRadioTimingButton.Size = New System.Drawing.Size(48, 17)
        Me.slowRadioTimingButton.TabIndex = 1
        Me.slowRadioTimingButton.TabStop = True
        Me.slowRadioTimingButton.Text = "Slow"
        Me.slowRadioTimingButton.UseVisualStyleBackColor = True
        '
        'debugRadioTimingButton
        '
        Me.debugRadioTimingButton.AutoSize = True
        Me.debugRadioTimingButton.Location = New System.Drawing.Point(10, 66)
        Me.debugRadioTimingButton.Name = "debugRadioTimingButton"
        Me.debugRadioTimingButton.Size = New System.Drawing.Size(57, 17)
        Me.debugRadioTimingButton.TabIndex = 2
        Me.debugRadioTimingButton.TabStop = True
        Me.debugRadioTimingButton.Text = "Debug"
        Me.debugRadioTimingButton.UseVisualStyleBackColor = True
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(382, 345)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "Form2"
        Me.Text = "Radio Configuration (Beta 4.X1)"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.TableLayoutPanel2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TableLayoutPanel3.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents TableLayoutPanel2 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Mod1UT1200 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod1UT440 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod1UT30 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod1UT220 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod1UT50 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod1UT144 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod1None As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Mod2None As System.Windows.Forms.RadioButton
    Friend WithEvents Mod2UT1200 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod2UT440 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod2UT30 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod2UT220 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod2UT50 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod2UT144 As System.Windows.Forms.RadioButton
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Mod3None As System.Windows.Forms.RadioButton
    Friend WithEvents Mod3UT1200 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod3UT440 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod3UT30 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod3UT220 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod3UT50 As System.Windows.Forms.RadioButton
    Friend WithEvents Mod3UT144 As System.Windows.Forms.RadioButton
    Friend WithEvents ChannelLists As System.Windows.Forms.Button
    Friend WithEvents TableLayoutPanel3 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Tsu7CheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents eTypeRadioCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents wideBandCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents debugRadioTimingButton As System.Windows.Forms.RadioButton
    Friend WithEvents slowRadioTimingButton As System.Windows.Forms.RadioButton
    Friend WithEvents normalRadioTimingButton As System.Windows.Forms.RadioButton
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
End Class
